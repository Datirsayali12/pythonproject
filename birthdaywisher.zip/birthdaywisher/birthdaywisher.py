import datetime as dt
import pandas as pd
import  smtplib
import random
today=(dt.datetime.now().month,dt.datetime.now().day)
df=pd.read_csv('birthdays.csv')


dict={(data_row['month'],data_row['day']): data_row for (index,data_row) in df.iterrows()}

my_email='datirsayali12@gmail.com'
my_pass='zztaxtrnssqmupuz'

if today in dict:
    birthday_person =dict[today]
    file_path = f"letter_templates/letter_{random.randint(1, 3)}.txt"
    with open(file_path) as letter_file:
        contents = letter_file.read()
        contents = contents.replace("[NAME]", birthday_person["name"])

    connection = smtplib.SMTP('smtp.gmail.com')
    connection.starttls()
    connection.login(my_email, my_pass)
    connection.sendmail(from_addr=my_email, to_addrs=my_email, msg=f"monday motivation {contents}")
